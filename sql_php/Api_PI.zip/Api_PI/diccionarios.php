<?php
include "config.php";
include "utils.php";
$dbConn = connect($db);

// Listar todos los diccionarios según FK de usuario, u obtener solo uno

if ($_SERVER['REQUEST_METHOD'] == 'GET') {
    if (isset($_GET['idDiccionario'])) {
        // Mostrar detalles de un diccionario
        $sql = $dbConn->prepare("SELECT * FROM Diccionarios WHERE idDiccionario=:idDiccionario");
        $sql->bindValue(':idDiccionario', $_GET['idDiccionario']);
    } else if (isset($_GET['idUsuarioFK'])) {
        // Todos los diccionarios de un usuario
        $sql = $dbConn->prepare("SELECT * FROM Diccionarios WHERE idUsuarioFK=:idUsuarioFK");
        $sql->bindValue(':idUsuarioFK', $_GET['idUsuarioFK']);
    } else {
        // No se proporcionaron parámetros válidos
        header("HTTP/1.1 400 Bad Request");
        echo json_encode(array("error" => "Missing parameters"));
        exit();
    }

    $sql->execute();
    $sql->setFetchMode(PDO::FETCH_ASSOC);
    header("HTTP/1.1 200 OK");
    echo json_encode($sql->fetchAll());
    exit();
}

// Crear un nuevo diccionario

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $input = $_POST;
    $sql = "INSERT INTO Diccionarios (nombreDiccionario, idUsuarioFK) VALUES (:nombreDiccionario, :idUsuarioFK)";
    $statement = $dbConn->prepare($sql);
    $statement->bindParam(':nombreDiccionario', $_POST['nombreDiccionario']);
    $statement->bindParam(':idUsuarioFK', $_POST['idUsuarioFK']);
    $statement->execute();
    $postId = $dbConn->lastInsertId();
    if ($postId) {
        $input['idDiccionario'] = $postId;
        header("HTTP/1.1 200 OK");
        echo json_encode($input);
        exit();
    }
}

// Borrar un diccionario

if ($_SERVER['REQUEST_METHOD'] == 'DELETE') {
    $idDiccionario = $_GET['idDiccionario'];
    $statement = $dbConn->prepare("DELETE FROM Diccionarios WHERE idDiccionario=:idDiccionario");
    $statement->bindValue(':idDiccionario', $idDiccionario);
    $statement->execute();
    header("HTTP/1.1 200 OK");
    exit();
}

// Actualizar un diccionario

if ($_SERVER['REQUEST_METHOD'] == 'PUT') {
    parse_str(file_get_contents("php://input"), $input);
    $sql = "UPDATE Diccionarios SET nombreDiccionario=:nombreDiccionario WHERE idDiccionario=:idDiccionario";
    $statement = $dbConn->prepare($sql);
    $statement->bindParam(':nombreDiccionario', $input['nombreDiccionario']);
    $statement->bindParam(':idDiccionario', $input['idDiccionario']);
    $statement->execute();
    header("HTTP/1.1 200 OK");
    exit();
}

header('Content-Type: application/json');
?>

