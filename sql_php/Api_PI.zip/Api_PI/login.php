<?php
include "config.php";
include "utils.php";
$dbConn = connect($db);
header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Verificar si se proporcionaron los datos de usuario y contraseña
    $data = json_decode(file_get_contents("php://input"));

    if (isset($data->nombreUsuario) && isset($data->claveUsuario)) {
        $username = $data->nombreUsuario;
        $password = $data->claveUsuario;
        
        // Preparar y ejecutar la consulta SQL para buscar el usuario
        $sql = $dbConn->prepare("SELECT * FROM usuarios WHERE nombreUsuario=:username AND claveUsuario=:password");
        $sql->bindParam(':username', $username);
        $sql->bindParam(':password', $password); 
        $sql->execute();
        $user = $sql->fetch(PDO::FETCH_ASSOC);
        
        // Verificar las credenciales del usuario
        if ($user) {
            // Autenticación exitosa
            http_response_code(200);
            echo json_encode(["message" => "login success"]);
        } else {
            // Autenticación fallida
            http_response_code(401);
            echo json_encode(["error" => "login unsuccessful"]);
        }
    } else {
        // Datos faltantes
        http_response_code(400);
        echo json_encode(["error" => "missing parameters"]);
    }
} else {
    // Método de solicitud incorrecto
    http_response_code(405);
    echo json_encode(["error" => "method not allowed"]);
}
?>
