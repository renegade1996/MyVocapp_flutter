<?php
include "config.php";
include "utils.php";
$dbConn = connect($db);
header('Content-Type: application/json');

// Obtener el ID de un usuario por su nombre de usuario o el nombre de usuario por su ID
if ($_SERVER['REQUEST_METHOD'] == 'GET') {
    // Verificar si se proporcionó el parámetro 'nombreUsuario'
    if (isset($_GET['nombreUsuario'])) {
        $nombreUsuario = $_GET['nombreUsuario'];

        // Consulta para buscar el usuario por su nombre de usuario
        $sql = $dbConn->prepare("SELECT idUsuario FROM Usuarios WHERE nombreUsuario=:nombreUsuario");
        $sql->bindValue(':nombreUsuario', $nombreUsuario);
        $sql->execute();

        // Verificar si se encontró el usuario
        if ($sql->rowCount() > 0) {
            $userData = $sql->fetch(PDO::FETCH_ASSOC);
            $userId = $userData['idUsuario'];

            // Devolver el ID del usuario
            header("HTTP/1.1 200 OK");
            echo json_encode(array("message" => "User found", "data" => array("idUsuario" => $userId)));
            exit();
        } else {
            // El usuario no fue encontrado
            header("HTTP/1.1 404 Not Found");
            echo json_encode(array("error" => "User not found"));
            exit();
        }
    }
    elseif (isset($_GET['idUsuario'])) {
       $idUsuario = $_GET['idUsuario'];
       $sql = "SELECT nombreUsuario FROM Usuarios WHERE idUsuario = :idUsuario";
       $statement = $dbConn->prepare($sql);
       $statement->bindParam(':idUsuario', $idUsuario);

    try {
        $statement->execute();

        if ($statement->rowCount() > 0) {
            $userData = $statement->fetch(PDO::FETCH_ASSOC);
            $username = $userData['nombreUsuario'];

            header("HTTP/1.1 200 OK");
            echo json_encode(array("message" => "Username found", "data" => array("nombreUsuario" => $username)));
            exit();
        } else {
            header("HTTP/1.1 404 Not Found");
            echo json_encode(array("error" => "Username not found"));
            exit();
        }
    } catch (PDOException $e) {
        header("HTTP/1.1 500 Internal Server Error");
        echo json_encode(array("error" => "Database error: " . $e->getMessage()));
        exit();
    }
  }
}

// Crear un nuevo usuario
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $input = json_decode(file_get_contents('php://input'), true);

    if (!isset($input['nombreUsuario']) || !isset($input['claveUsuario'])) {
        http_response_code(400);
        echo json_encode(array("error" => "missing parameters"));
        exit();
    }

    $nombreUsuarioNormalizado = strtolower(str_replace(' ', '', $input['nombreUsuario']));

    $sqlCheck = $dbConn->prepare("SELECT EXISTS(SELECT 1 FROM usuarios WHERE LOWER(REPLACE(nombreUsuario, ' ', '')) = :nombreUsuario) AS userExists");
    $sqlCheck->bindValue(':nombreUsuario', $nombreUsuarioNormalizado);
    $sqlCheck->execute();
    $result = $sqlCheck->fetch(PDO::FETCH_ASSOC);

    if ($result['userExists'] == 1) {
        echo json_encode(array("error" => "exists"));
        exit();
    } else {
        $sql = "INSERT INTO usuarios (nombreUsuario, claveUsuario) VALUES (:nombreUsuario, :claveUsuario)";
        $statement = $dbConn->prepare($sql);
        $statement->bindParam(':nombreUsuario', $input['nombreUsuario']);
        $statement->bindParam(':claveUsuario', $input['claveUsuario']);
        
        if ($statement->execute()) {
            $postId = $dbConn->lastInsertId();
            $response = array("idUsuario" => $postId, "nombreUsuario" => $input['nombreUsuario']);
            http_response_code(201);
            echo json_encode($response);
            exit();
        } else {
            http_response_code(500);
            echo json_encode(array("error" => "could not create user"));
            exit();
        }
    }
}

// Borrar un usuario y todas sus asociaciones con diccionarios y entradas
if ($_SERVER['REQUEST_METHOD'] == 'DELETE') {
    $idUsuario = isset($_GET['idUsuario']) ? $_GET['idUsuario'] : null;

    if (!$idUsuario) {
        header("HTTP/1.1 400 Bad Request");
        echo json_encode(array("error" => "User ID is missing"));
        exit();
    }

    try {
        $dbConn->beginTransaction();

        $statementEntry = $dbConn->prepare("DELETE FROM Entradas WHERE idDiccionarioFK IN (SELECT idDiccionario FROM Diccionarios WHERE idUsuarioFK=:idUsuario)");
        $statementEntry->bindValue(':idUsuario', $idUsuario);
        $statementEntry->execute();

        $statementDict = $dbConn->prepare("DELETE FROM Diccionarios WHERE idUsuarioFK=:idUsuario");
        $statementDict->bindValue(':idUsuario', $idUsuario);
        $statementDict->execute();

        $statementUser = $dbConn->prepare("DELETE FROM Usuarios WHERE idUsuario=:idUsuario");
        $statementUser->bindValue(':idUsuario', $idUsuario);
        $statementUser->execute();

        $dbConn->commit();

        header("HTTP/1.1 200 OK");
        echo json_encode(array("message" => "User and associated data deleted successfully"));
        exit();
    } catch (PDOException $e) {
        $dbConn->rollBack();

        header("HTTP/1.1 500 Internal Server Error");
        echo json_encode(array("error" => "Failed to delete user and associated data: " . $e->getMessage()));
        exit();
    }
}

// Actualizar un usuario
if ($_SERVER['REQUEST_METHOD'] == 'PUT') {
    $input = json_decode(file_get_contents("php://input"), true);

    if (isset($input['idUsuario'], $input['claveUsuario'], $input['nuevaClaveUsuario'])) {
        $idUsuario = $input['idUsuario'];
        $claveActual = $input['claveUsuario'];
        $nuevaClave = $input['nuevaClaveUsuario'];

        $sqlCheckPassword = $dbConn->prepare("SELECT claveUsuario FROM Usuarios WHERE idUsuario = :idUsuario");
        $sqlCheckPassword->bindValue(':idUsuario', $idUsuario);
        $sqlCheckPassword->execute();
        $result = $sqlCheckPassword->fetch(PDO::FETCH_ASSOC);

        if ($result) {
            $passwordFromDB = $result['claveUsuario'];

            if ($claveActual === $passwordFromDB) {
                $sql = "UPDATE Usuarios SET claveUsuario=:nuevaClave WHERE idUsuario=:idUsuario";
                $statement = $dbConn->prepare($sql);
                $statement->bindParam(':nuevaClave', $nuevaClave);
                $statement->bindParam(':idUsuario', $idUsuario);

                try {
                    $statement->execute();

                    if ($statement->rowCount() > 0) {
                        header("HTTP/1.1 200 OK");
                        echo json_encode(array("message" => "User password updated successfully"));
                        exit();
                    } else {
                        header("HTTP/1.1 500 Internal Server Error");
                        echo json_encode(array("error" => "Could not update user password"));
                        exit();
                    }
                } catch (PDOException $e) {
                    header("HTTP/1.1 500 Internal Server Error");
                    echo json_encode(array("error" => "Database error: " . $e->getMessage()));
                    exit();
                }
            } else {
                header("HTTP/1.1 400 Bad Request");
                echo json_encode(array("error" => "Current password does not match"));
                exit();
            }
        } else {
            header("HTTP/1.1 400 Bad Request");
            echo json_encode(array("error" => "User not found or error retrieving password"));
            exit();
        }
    } elseif (isset($input['idUsuario'], $input['nombreUsuario'])) {
        $idUsuario = $input['idUsuario'];
        $nombreUsuario = strtolower(str_replace(' ', '', $input['nombreUsuario']));

        $sqlCheck = "SELECT COUNT(*) FROM Usuarios WHERE LOWER(REPLACE(nombreUsuario, ' ', '')) = :nombreUsuario AND idUsuario != :idUsuario";
        $statementCheck = $dbConn->prepare($sqlCheck);
        $statementCheck->bindParam(':nombreUsuario', $nombreUsuario);
        $statementCheck->bindParam(':idUsuario', $idUsuario);

        try {
            $statementCheck->execute();
            $count = $statementCheck->fetchColumn();

            if ($count > 0) {
                header("HTTP/1.1 409 Conflict");
                echo json_encode(array("error" => "Username already exists"));
                exit();
            } else {
                $sql = "UPDATE Usuarios SET nombreUsuario=:nombreUsuario WHERE idUsuario=:idUsuario";
                $statement = $dbConn->prepare($sql);
                $statement->bindParam(':nombreUsuario', $input['nombreUsuario']);
                $statement->bindParam(':idUsuario', $idUsuario);

                try {
                    $statement->execute();

                    if ($statement->rowCount() > 0) {
                        header("HTTP/1.1 200 OK");
                        echo json_encode(array("message" => "Username updated successfully"));
                        exit();
                    } else {
                        header("HTTP/1.1 500 Internal Server Error");
                        echo json_encode(array("error" => "Could not update username"));
                        exit();
                    }
                } catch (PDOException $e) {
                    header("HTTP/1.1 500 Internal Server Error");
                    echo json_encode(array("error" => "Database error: " . $e->getMessage()));
                    exit();
                }
            }
        } catch (PDOException $e) {
            header("HTTP/1.1 500 Internal Server Error");
            echo json_encode(array("error" => "Database error: " . $e->getMessage()));
            exit();
        }
    } else {
        header("HTTP/1.1 400 Bad Request");
        echo json_encode(array("error" => "Missing parameters"));
        exit();
    }
}

// En caso de que ninguna de las opciones anteriores se haya ejecutado
header('Content-Type: application/json');
?>
