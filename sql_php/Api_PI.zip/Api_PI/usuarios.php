<?php
include "config.php";
include "utils.php";
$dbConn = connect($db);
header('Content-Type: application/json');

// Obtener el ID de un usuario por su nombre de usuario o el nombre de usuario por su ID
if ($_SERVER['REQUEST_METHOD'] == 'GET') {
    // Verificar si se proporcionó el parámetro 'nombreUsuario'
    if (isset($_GET['nombreUsuario'])) {
        $nombreUsuario = $_GET['nombreUsuario'];

        // Consulta para buscar el usuario por su nombre de usuario
        $sql = $dbConn->prepare("SELECT idUsuario FROM Usuarios WHERE nombreUsuario=:nombreUsuario");
        $sql->bindValue(':nombreUsuario', $nombreUsuario);
        $sql->execute();

        // Verificar si se encontró el usuario
        if ($sql->rowCount() > 0) {
            $userData = $sql->fetch(PDO::FETCH_ASSOC);
            $userId = $userData['idUsuario'];

            // Devolver el ID del usuario
            header("HTTP/1.1 200 OK");
            echo json_encode(array("message" => "User found", "data" => array("idUsuario" => $userId)));
            exit();
        } else {
            // El usuario no fue encontrado
            header("HTTP/1.1 404 Not Found");
            echo json_encode(array("error" => "User not found"));
            exit();
        }
    }
    // Verificar si se proporcionó el parámetro 'idUsuario'
    elseif (isset($_GET['idUsuario'])) {
        $idUsuario = $_GET['idUsuario'];

        // Consulta para buscar el nombre de usuario por su ID de usuario
        $sql = $dbConn->prepare("SELECT nombreUsuario FROM Usuarios WHERE idUsuario=:idUsuario");
        $sql->bindValue(':idUsuario', $idUsuario);
        $sql->execute();

        // Verificar si se encontró el nombre de usuario
        if ($sql->rowCount() > 0) {
            $userData = $sql->fetch(PDO::FETCH_ASSOC);
            $username = $userData['nombreUsuario'];

            // Devolver el nombre de usuario
            header("HTTP/1.1 200 OK");
            echo json_encode(array("message" => "Username found", "data" => array("nombreUsuario" => $username)));
            exit();
        } else {
            // El nombre de usuario no fue encontrado
            header("HTTP/1.1 404 Not Found");
            echo json_encode(array("error" => "Username not found"));
            exit();
        }
    }
}


// Crear un nuevo usuario
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $input = json_decode(file_get_contents('php://input'), true); // Obtener datos de entrada del cuerpo de la solicitud

    // Comprobar parámetros
    if (!isset($input['nombreUsuario']) || !isset($input['claveUsuario'])) {
        // Faltan parámetros
        http_response_code(400); // Error de solicitud incorrecta
        echo json_encode(array("error" => "missing parameters"));
        exit();
    }

    // Verificar si el nombre de usuario ya existe
    $sqlCheck = $dbConn->prepare("SELECT EXISTS(SELECT 1 FROM usuarios WHERE nombreUsuario = :nombreUsuario) AS userExists");
    $sqlCheck->bindValue(':nombreUsuario', $input['nombreUsuario']);
    $sqlCheck->execute();
    $result = $sqlCheck->fetch(PDO::FETCH_ASSOC);

    if ($result['userExists'] == 1) {
        // Usuario existente, devuelve un error
        echo json_encode(array("error" => "exists"));
        exit();
    } else {
        // El nombre de usuario no existe, crea un nuevo usuario
        $sql = "INSERT INTO usuarios (nombreUsuario, claveUsuario) VALUES (:nombreUsuario, :claveUsuario)";
        $statement = $dbConn->prepare($sql);
        $statement->bindParam(':nombreUsuario', $input['nombreUsuario']);
        $statement->bindParam(':claveUsuario', $input['claveUsuario']);
        
        if ($statement->execute()) {
            $postId = $dbConn->lastInsertId();
            $response = array("idUsuario" => $postId, "nombreUsuario" => $input['nombreUsuario']);
            http_response_code(201); // Creado
            echo json_encode($response);
            exit();
        } else {
            // Error al crear el usuario
            http_response_code(500); // Error interno del servidor
            echo json_encode(array("error" => "could not create user"));
            exit();
        }
    }
}

// Borrar un usuario y todas sus asociaciones con diccionarios y entradas
if ($_SERVER['REQUEST_METHOD'] == 'DELETE') {
    // Obtener el ID del usuario a eliminar
    $idUsuario = isset($_GET['idUsuario']) ? $_GET['idUsuario'] : null;

    if (!$idUsuario) {
        // Si no se proporciona el ID del usuario, devolver un error
        header("HTTP/1.1 400 Bad Request");
        echo json_encode(array("error" => "User ID is missing"));
        exit();
    }

    try {
        // Iniciar una transacción
        $dbConn->beginTransaction();
	
	// Borrar todas las entradas asociadas a los diccionarios del usuario
	$statementEntry = $dbConn->prepare("DELETE FROM Entradas WHERE idDiccionarioFK IN (SELECT idDiccionario FROM Diccionarios WHERE idUsuarioFK=:idUsuario)");
	$statementEntry->bindValue(':idUsuario', $idUsuario);
	$statementEntry->execute();

        // Borrar todos los diccionarios asociados al usuario
	$statementDict = $dbConn->prepare("DELETE FROM Diccionarios WHERE idUsuarioFK=:idUsuario");
	$statementDict->bindValue(':idUsuario', $idUsuario);
	$statementDict->execute();

	// Finalmente, eliminar el usuario
	$statementUser = $dbConn->prepare("DELETE FROM Usuarios WHERE idUsuario=:idUsuario");
	$statementUser->bindValue(':idUsuario', $idUsuario);
	$statementUser->execute();

        // Confirmar la transacción
        $dbConn->commit();

        // Devolver respuesta exitosa
        header("HTTP/1.1 200 OK");
        echo json_encode(array("message" => "User and associated data deleted successfully"));
        exit();
    } catch (PDOException $e) {
        // Si hay algún error, revertir la transacción
        $dbConn->rollBack();

        // Devolver respuesta de error
        header("HTTP/1.1 500 Internal Server Error");
        echo json_encode(array("error" => "Failed to delete user and associated data: " . $e->getMessage()));
        exit();
    }
}

// Actualizar un usuario

if ($_SERVER['REQUEST_METHOD'] == 'PUT') {
    // Obtener los datos de entrada del cuerpo de la solicitud JSON
    $input = json_decode(file_get_contents("php://input"), true);

    // Verificar si se proporcionaron los parámetros necesarios para cambiar la contraseña
    if (isset($input['idUsuario'], $input['claveUsuario'], $input['nuevaClaveUsuario'])) {
        $idUsuario = $input['idUsuario'];
        $claveActual = $input['claveUsuario'];
        $nuevaClave = $input['nuevaClaveUsuario'];

        // Verificar si la contraseña actual coincide con la almacenada en la base de datos
        $sqlCheckPassword = $dbConn->prepare("SELECT claveUsuario FROM pi_diccionarios.usuarios WHERE idUsuario = :idUsuario");
        $sqlCheckPassword->bindValue(':idUsuario', $idUsuario);
        $sqlCheckPassword->execute();
        $result = $sqlCheckPassword->fetch(PDO::FETCH_ASSOC);

        if ($result) {
            // Obtener el hash de la contraseña almacenada en la base de datos
            $passwordFromDB = $result['claveUsuario'];

            // Verificar si la contraseña actual coincide
            if ($claveActual === $passwordFromDB) {
                // La contraseña actual coincide, continuar con la actualización

                // Actualizar la clave del usuario
                $sql = "UPDATE Usuarios SET claveUsuario=:nuevaClave WHERE idUsuario=:idUsuario";
                $statement = $dbConn->prepare($sql);
                $statement->bindParam(':nuevaClave', $nuevaClave);
                $statement->bindParam(':idUsuario', $idUsuario);

                // Ejecutar la consulta SQL
                try {
                    $statement->execute();

                    if ($statement->rowCount() > 0) {
                        header("HTTP/1.1 200 OK");
                        echo json_encode(array("message" => "User password updated successfully"));
                        exit();
                    } else {
                        // No se pudo actualizar la contraseña del usuario
                        header("HTTP/1.1 500 Internal Server Error");
                        echo json_encode(array("error" => "Could not update user password"));
                        exit();
                    }
                } catch (PDOException $e) {
                    // Error en la ejecución de la consulta SQL
                    header("HTTP/1.1 500 Internal Server Error");
                    echo json_encode(array("error" => "Database error: " . $e->getMessage()));
                    exit();
                }
            } else {
                // La contraseña actual no coincide, devolver un error
                header("HTTP/1.1 400 Bad Request");
                echo json_encode(array("error" => "Current password does not match"));
                exit();
            }
        } else {
            // Usuario no encontrado o error al recuperar la contraseña
            header("HTTP/1.1 400 Bad Request");
            echo json_encode(array("error" => "User not found or error retrieving password"));
            exit();
        }
    }
    // Verificar si se proporcionaron los parámetros necesarios para cambiar el nombre de usuario
    elseif (isset($input['idUsuario'], $input['nombreUsuario'])) {
        $idUsuario = $input['idUsuario'];
        $nombreUsuario = $input['nombreUsuario'];

        // Actualizar el nombre de usuario
        $sql = "UPDATE Usuarios SET nombreUsuario=:nombreUsuario WHERE idUsuario=:idUsuario";
        $statement = $dbConn->prepare($sql);
        $statement->bindParam(':nombreUsuario', $nombreUsuario);
        $statement->bindParam(':idUsuario', $idUsuario);

        // Ejecutar la consulta SQL
        try {
            $statement->execute();

            if ($statement->rowCount() > 0) {
                header("HTTP/1.1 200 OK");
                echo json_encode(array("message" => "Username updated successfully"));
                exit();
            } else {
                // No se pudo actualizar el nombre de usuario
                header("HTTP/1.1 500 Internal Server Error");
                echo json_encode(array("error" => "Could not update username"));
                exit();
            }
        } catch (PDOException $e) {
            // Error en la ejecución de la consulta SQL
            header("HTTP/1.1 500 Internal Server Error");
            echo json_encode(array("error" => "Database error: " . $e->getMessage()));
            exit();
        }
    } else {
        // Si no se proporcionan los parámetros necesarios, devolver un error de solicitud incorrecta
        header("HTTP/1.1 400 Bad Request");
        echo json_encode(array("error" => "Missing parameters"));
        exit();
    }
}


// En caso de que ninguna de las opciones anteriores se haya ejecutado
header('Content-Type: application/json');
?>
