<?php
$db = [
    'host' => 'localhost',
    'username' => 'userPI',
    'password' => 'Studium2024;',
    'db' => 'pi_diccionarios'
];
?>
