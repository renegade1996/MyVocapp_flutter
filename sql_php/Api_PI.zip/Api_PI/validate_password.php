<?php
include "config.php";
include "utils.php";

// Conectar a la base de datos
$dbConn = connect($db);

// Establecer el tipo de contenido de la respuesta como JSON
header('Content-Type: application/json');

// Recibir datos enviados por POST (en formato JSON)
$input = json_decode(file_get_contents('php://input'), true);

// Verificar si se recibieron los datos esperados
if (isset($input['idUsuario']) && isset($input['claveUsuario'])) {
    // Obtener datos del usuario y la contraseña del input
    $idUsuario = $input['idUsuario'];
    $claveUsuario = $input['claveUsuario'];

    // Consulta SQL para verificar la contraseña actual del usuario
    $sql = "SELECT idUsuario FROM usuarios WHERE idUsuario = :idUsuario AND claveUsuario = :claveUsuario";

    try {
        // Preparar la consulta
        $stmt = $dbConn->prepare($sql);

        // Vincular parámetros
        $stmt->bindParam(':idUsuario', $idUsuario);
        $stmt->bindParam(':claveUsuario', $claveUsuario);

        // Ejecutar la consulta
        $stmt->execute();

        // Obtener el resultado de la consulta
        $user = $stmt->fetch(PDO::FETCH_ASSOC);

        // Verificar si se encontró un usuario con la contraseña proporcionada
        if ($user) {
            // Si se encontró, enviar una respuesta JSON con 'valid' establecido a true
            echo json_encode(array('valid' => true));
        } else {
            // Si no se encontró, enviar una respuesta JSON con 'valid' establecido a false
            echo json_encode(array('valid' => false));
        }

    } catch (PDOException $e) {
        // En caso de error en la consulta, enviar una respuesta JSON con un mensaje de error
        echo json_encode(array('error' => $e->getMessage()));
    }

} else {
    // Si no se recibieron los datos esperados, enviar una respuesta JSON con un mensaje de error
    echo json_encode(array('error' => 'Missing data'));
}
?>
