<?php
include "config.php";
include "utils.php";
$dbConn = connect($db);

// Listar todas las entradas u obtener solo una

if ($_SERVER['REQUEST_METHOD'] == 'GET') {
    if (isset($_GET['idEntrada'])) {
        // Mostrar una entrada
        $sql = $dbConn->prepare("SELECT * FROM Entradas WHERE idEntrada=:idEntrada");
        $sql->bindValue(':idEntrada', $_GET['idEntrada']);
        $sql->execute();
        header("HTTP/1.1 200 OK");
        echo json_encode($sql->fetch(PDO::FETCH_ASSOC));
        exit();
    } elseif (isset($_GET['idDiccionarioFK'])) {
        // Mostrar todas las entradas del diccionario especificado
        $sql = $dbConn->prepare("SELECT * FROM Entradas WHERE idDiccionarioFK=:idDiccionarioFK");
        $sql->bindValue(':idDiccionarioFK', $_GET['idDiccionarioFK']);
        $sql->execute();
        header("HTTP/1.1 200 OK");
        echo json_encode($sql->fetchAll());
        exit();
    } elseif (isset($_GET['tipoEntrada'])) {
        // Mostrar solo las entradas con tipoEntrada=true
        $sql = $dbConn->prepare("SELECT * FROM Entradas WHERE tipoEntrada=1");
        $sql->execute();
        header("HTTP/1.1 200 OK");
        echo json_encode($sql->fetchAll());
        exit();
    } else {
        // Mostrar lista de todas las entradas
        $sql = $dbConn->prepare("SELECT * FROM Entradas");
        $sql->execute();
        $sql->setFetchMode(PDO::FETCH_ASSOC);
        header("HTTP/1.1 200 OK");
        echo json_encode($sql->fetchAll());
        exit();
    }
}


// Crear una nueva entrada

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $input = $_POST;
    $sql = "INSERT INTO Entradas (tituloEntrada, descripcionEntrada, ejemploEntrada, trucoEntrada, tipoEntrada, idDiccionarioFK) 
            VALUES (:tituloEntrada, :descripcionEntrada, :ejemploEntrada, :trucoEntrada, :tipoEntrada, :idDiccionarioFK)";
    $statement = $dbConn->prepare($sql);
    $statement->bindParam(':tituloEntrada', $_POST['tituloEntrada']);
    $statement->bindParam(':descripcionEntrada', $_POST['descripcionEntrada']);
    $statement->bindParam(':ejemploEntrada', $_POST['ejemploEntrada']);
    $statement->bindParam(':trucoEntrada', $_POST['trucoEntrada']);
    $statement->bindParam(':tipoEntrada', $_POST['tipoEntrada']);
    $statement->bindParam(':idDiccionarioFK', $_POST['idDiccionarioFK']);
    $statement->execute();
    $postId = $dbConn->lastInsertId();
    if ($postId) {
        $input['idEntrada'] = $postId;
        header("HTTP/1.1 200 OK");
        echo json_encode($input);
        exit();
    }
}

// Borrar una entrada o todas las entradas de un diccionario

if ($_SERVER['REQUEST_METHOD'] == 'DELETE') {
    if (isset($_GET['idEntrada'])) {
        $idEntrada = $_GET['idEntrada'];
        $statement = $dbConn->prepare("DELETE FROM Entradas WHERE idEntrada=:idEntrada");
        $statement->bindValue(':idEntrada', $idEntrada);
        $statement->execute();
        header("HTTP/1.1 200 OK");
        exit();
    } elseif (isset($_GET['idDiccionarioFK'])) {
        // Borrar todas las entradas asociadas a un diccionario
        $idDiccionarioFK = $_GET['idDiccionarioFK'];
        $statement = $dbConn->prepare("DELETE FROM Entradas WHERE idDiccionarioFK=:idDiccionarioFK");
        $statement->bindValue(':idDiccionarioFK', $idDiccionarioFK);
        $statement->execute();
        header("HTTP/1.1 200 OK");
        exit();
    }
}

// Actualizar una entrada

if ($_SERVER['REQUEST_METHOD'] == 'PUT') {
    parse_str(file_get_contents("php://input"), $input);
    $sql = "UPDATE Entradas SET tituloEntrada=:tituloEntrada, descripcionEntrada=:descripcionEntrada, 
            ejemploEntrada=:ejemploEntrada, trucoEntrada=:trucoEntrada, tipoEntrada=:tipoEntrada, 
            idDiccionarioFK=:idDiccionarioFK WHERE idEntrada=:idEntrada";
    $statement = $dbConn->prepare($sql);
    $statement->bindParam(':idEntrada', $input['idEntrada']);
    $statement->bindParam(':tituloEntrada', $input['tituloEntrada']);
    $statement->bindParam(':descripcionEntrada', $input['descripcionEntrada']);
    $statement->bindParam(':ejemploEntrada', $input['ejemploEntrada']);
    $statement->bindParam(':trucoEntrada', $input['trucoEntrada']);
    $statement->bindParam(':tipoEntrada', $input['tipoEntrada']);
    $statement->bindParam(':idDiccionarioFK', $input['idDiccionarioFK']);
    $statement->execute();
    header("HTTP/1.1 200 OK");
    exit();
}

// En caso de que ninguna de las opciones anteriores se haya ejecutado

header('Content-Type: application/json');
?>
